﻿using System.ComponentModel.DataAnnotations.Schema;

namespace SecretSantaApp.Models
{
    public class Participant
    {
        public int Id { get; set; }

        // Klucz obcy do gry
        public int GameId { get; set; }

        [ForeignKey("GameId")]
        public Game Game { get; set; }

        // ID uczestnika (użytkownika)
        public string UserId { get; set; }

        public ApplicationUser User { get; set; }

        // ID użytkownika, który został przydzielony do obdarowania
        public string? AssignedUserId { get; set; }

        [ForeignKey("AssignedUserId")]
        public ApplicationUser AssignedUser { get; set; }

        // Preferencje prezentowe uczestnika
        public string? GiftPreference { get; set; }
    }
}
