﻿using System.ComponentModel.DataAnnotations;

namespace SecretSantaApp.Models
{
    public class CreateGameViewModel
    {
        [Required]
        public string Name { get; set; }

        // Lista emaili uczestników (oddzielona przecinkami)
        public string ParticipantEmails { get; set; }
    }
}
