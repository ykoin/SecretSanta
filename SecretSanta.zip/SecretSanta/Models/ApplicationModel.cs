﻿using Microsoft.AspNetCore.Identity;

namespace SecretSantaApp.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Dodatkowa właściwość użytkownika
        public string? FullName { get; set; }
    }
}
