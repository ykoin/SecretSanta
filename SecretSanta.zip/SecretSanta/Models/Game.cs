﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace SecretSantaApp.Models
{
    public class Game
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        // ID użytkownika, który stworzył grę
        public string OwnerId { get; set; }

        // Lista uczestników gry
        public ICollection<Participant> Participants { get; set; }
    }
}
