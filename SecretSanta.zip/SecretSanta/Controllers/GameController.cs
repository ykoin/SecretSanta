﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SecretSantaApp.Data;
using SecretSantaApp.Models;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;

namespace SecretSantaApp.Controllers
{
    [Authorize]
    public class GameController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public GameController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: /Game/
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            // Pobranie gier, w których uczestniczy użytkownik
            var games = await _context.Participants
                .Where(p => p.UserId == user.Id)
                .Include(p => p.Game)
                .Select(p => p.Game)
                .ToListAsync();
            return View(games);
        }

        // GET: /Game/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Game/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateGameViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(User);
                // Utworzenie nowej gry
                var game = new Game
                {
                    Name = model.Name,
                    OwnerId = user.Id,
                    Participants = new List<Participant>()
                };

                // Dodanie właściciela gry jako uczestnika
                game.Participants.Add(new Participant { UserId = user.Id });

                // Przetwarzanie dodatkowych uczestników (lista emaili oddzielonych przecinkami)
                if (!string.IsNullOrEmpty(model.ParticipantEmails))
                {
                    var emails = model.ParticipantEmails.Split(',', StringSplitOptions.RemoveEmptyEntries);
                    foreach (var email in emails)
                    {
                        var trimmedEmail = email.Trim();
                        var participantUser = await _userManager.FindByEmailAsync(trimmedEmail);
                        if (participantUser != null && participantUser.Id != user.Id)
                        {
                            if (!game.Participants.Any(p => p.UserId == participantUser.Id))
                            {
                                game.Participants.Add(new Participant { UserId = participantUser.Id });
                            }
                        }
                    }
                }
                _context.Games.Add(game);
                await _context.SaveChangesAsync();

                // Logika losowego przydziału uczestników dla Secret Santa
                AssignSecretSanta(game);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // GET: /Game/Details/{id}
        public async Task<IActionResult> Details(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            // Pobranie gry wraz z uczestnikami
            var game = await _context.Games
                .Include(g => g.Participants)
                    .ThenInclude(p => p.User)
                .Include(g => g.Participants)
                    .ThenInclude(p => p.AssignedUser)
                .FirstOrDefaultAsync(g => g.Id == id);

            if (game == null)
                return NotFound();

            // Sprawdzenie, czy bieżący użytkownik jest uczestnikiem gry
            var participant = game.Participants.FirstOrDefault(p => p.UserId == user.Id);
            if (participant == null)
                return Unauthorized();

            return View(game);
        }

        // POST: /Game/UpdateGiftPreference/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateGiftPreference(int id, string giftPreference)
        {
            var user = await _userManager.GetUserAsync(User);
            var participant = await _context.Participants
                .FirstOrDefaultAsync(p => p.GameId == id && p.UserId == user.Id);

            if (participant == null)
                return Unauthorized();

            participant.GiftPreference = giftPreference;
            await _context.SaveChangesAsync();
            return RedirectToAction("Details", new { id = id });
        }

        private void AssignSecretSanta(Game game)
        {
            var participants = game.Participants.ToList();
            if (participants.Count < 2)
                return;

            var random = new Random();
            List<Participant> assignedList = null;
            bool validAssignment = false;
            int attempts = 0;
            int maxAttempts = 100;

            // Losujemy permutację aż nikt nie będzie przypisany sam do siebie
            while (!validAssignment && attempts < maxAttempts)
            {
                assignedList = participants.OrderBy(x => random.Next()).ToList();
                validAssignment = true;
                for (int i = 0; i < participants.Count; i++)
                {
                    if (assignedList[i].UserId == participants[i].UserId)
                    {
                        validAssignment = false;
                        break;
                    }
                }
                attempts++;
            }

            if (!validAssignment)
            {
                throw new Exception("Nie udało się wygenerować poprawnego przydziału Secret Santa bez samoprzypisania.");
            }

            // Przypisanie uczestników zgodnie z wygenerowaną permutacją
            for (int i = 0; i < participants.Count; i++)
            {
                participants[i].AssignedUserId = assignedList[i].UserId;
            }
        }

    }
}
